# loss_mob/__init__.py

__version__ = "0.1.5"

from .loss_mob import *
