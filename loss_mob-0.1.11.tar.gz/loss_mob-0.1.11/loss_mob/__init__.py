# loss_mob/__init__.py

__version__ = "0.1.11"

from .loss_mob import *
