# loss_mob/__init__.py

__version__ = "0.1.6"

from .loss_mob import *
